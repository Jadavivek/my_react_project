export type User = {
  id: string;
  name: string;
  available: boolean;
};
